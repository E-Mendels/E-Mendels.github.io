from csvReader import *
import folium

def importCSVRemoveSpace(fichier : str, separateur = ";"):
    donnéesDuFichier = open(fichier,'r')
    listLigne = []
    listeDico = []
    for i in donnéesDuFichier:
        s = i.strip().replace(' ','').replace('\n','')
        listLigne.append(s.split(';'))
    for k in range(1,len(listLigne)):
        dico = {}
        for j in range(len(listLigne[0])):
            dico[listLigne[0][j]] = listLigne[k][j].replace('-',' ')
        listeDico.append(dico)        
    return listeDico

# derivé du import csv du pauvre, fait pace qu'il y avait des espace dans la base de donnéee utilisé
    
listeDoc = ["/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_1965_t2.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_1969_t1.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_1969_t2.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_1974_t1.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_1974_t2.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_1981_t1.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_1981_t2.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_1988_t1.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_1988_t2.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_1995_t1_2.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_1995_t2.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_2002_t1.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_2002_t2.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_2007_t1.csv",
"/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/donnee/rslt_2007_t2.csv"]  

listeNom = ['1965_t2','1969_t1','1969_t2','1974_t1','1974_t2','1981_t1','1981_t2',
            '1988_t1','1988_t2','1995_t1','1995_t2','2002_t1','2002_t2','2007_t1','2007_t2']
dicoDeLaMort = {}

for index1 in range(len(listeDoc)):
    dicoDeLaMort[listeNom[index1]]= importCSVRemoveSpace(listeDoc[index1])
    
c=76
     
for index2 in dicoDeLaMort.keys():
    l = 0
    longueur = len(dicoDeLaMort[index2])
    while l < longueur :
        if len(dicoDeLaMort[index2][l]['Code_departement']) > 2 or dicoDeLaMort[index2][l]['Code_departement'] == '99':
            del dicoDeLaMort[index2][l]
            l = l-1
            longueur = len(dicoDeLaMort[index2])    
        l+=1

def calcul(dicOriginal):
    dicResTot = {}
    for nomCourant in dicOriginal.keys():
        listeResultat = []
        indexListe = 0
        while indexListe < len(dicOriginal[nomCourant]):
            dicCourant = dicOriginal[nomCourant][indexListe]
            indexDepIni = 1
            totInscritsParDep = int(dicCourant['Inscrits'])
            totVotantsParDep = int(dicCourant['Votants'])
            while ((indexListe+indexDepIni) < len(dicOriginal[nomCourant])) and dicCourant['Code_departement'] == dicOriginal[nomCourant][indexListe+indexDepIni]['Code_departement']:
                totInscritsParDep += int(dicOriginal[nomCourant][indexListe+indexDepIni]['Inscrits'])
                totVotantsParDep += int(dicOriginal[nomCourant][indexListe+indexDepIni]['Votants'])
                indexDepIni += 1
            dicResultat = dicCourant
            dicResultat['Inscrits'] = totInscritsParDep
            dicResultat['Votants']  = totVotantsParDep
            dicResultat['PourcentageAbstention'] = (1-totVotantsParDep/totInscritsParDep)*100
            dicResultat['abstention']= totInscritsParDep-totVotantsParDep
            listeResultat.append(dicResultat) 
            indexListe += indexDepIni
        dicResTot[nomCourant] = listeResultat
    return dicResTot

dicoDeLaMort = calcul(dicoDeLaMort)

coordDep = importCSV('/Users/Elisa/Desktop/1G9/NSI/NSI_CSV/projet/hotels-de-prefectures-fr.csv')

for numDep in coordDep:
    numDep['DeptNum'] = numDep['DeptNum'].zfill(2)
    
    
for table in dicoDeLaMort.keys():
    for liste in range(len(dicoDeLaMort[table])):
        dicoDeLaMort[table][liste]['Code_departement'] = dicoDeLaMort[table][liste]['Code_departement'].zfill(2)
    for index3 in range(len(dicoDeLaMort[table])):
        for index4 in range(len(coordDep)):
            if dicoDeLaMort[table][index3]['Code_departement'] == coordDep[index4]['DeptNum']:
                dicoDeLaMort[table][index3]['latitude'] = coordDep[index4]['LatDD']
                dicoDeLaMort[table][index3]['longitude'] = coordDep[index4]['LonDD']

def changementArchi(dicBase):
    ListeRes = []
    for dep1 in dicBase['2007_t2']:
        dicCour = {}
        dicCour['departement'] = dep1['Code_departement']
        dicCour['NomDepartment'] = dep1['departement']
        dicCour['longitude']= dep1['longitude']
        dicCour['latitude']= dep1['latitude']
        dicCour['PourcentageAbstention'] = []
        dicCour['abstention']= []
        ListeRes.append(dicCour)
    for annee in dicBase.keys():
        for index5 in range(len(dicBase[annee])):
            if ListeRes[index5]['departement'] == dicBase[annee][index5]['Code_departement']:
                dic = {'Annee' : annee, 'PourcentageAbstention' : int(dicBase[annee][index5]['PourcentageAbstention'])}
                dic2 = {'Annee' : annee, 'abstention' : int(dicBase[annee][index5]['abstention'])}
                ListeRes[index5]['PourcentageAbstention'].append(dic)
                ListeRes[index5]['abstention'].append(dic2)
            #Cas Département 20 qui devient 2A et 2B (Corse)
            elif ListeRes[index5]['departement'] == dicBase[annee][index5-1]['Code_departement']:
                dic = {'Annee' : annee, 'PourcentageAbstention' : int(dicBase[annee][index5-1]['PourcentageAbstention'])}
                dic2 = {'Annee' : annee, 'abstention' : int(dicBase[annee][index5]['abstention'])}
                ListeRes[index5]['PourcentageAbstention'].append(dic)
                ListeRes[index5]['abstention'].append(dic2)
    return ListeRes

dicoV2 = changementArchi(dicoDeLaMort)


m = folium.Map(
    location=[45.777222222222221, 3.084166666666667], # centrer sur clermond ferrand = environ au milieu de la france 
    zoom_start=6,
    tiles='Stamen Terrain'
)

m2 = folium.Map(
    location=[45.777222222222221, 3.084166666666667], # centrer sur clermond ferrand = environ au milieu de la france 
    zoom_start=6,
    tiles='Stamen Terrain'
)

for ligneParDepartement in dicoV2:
    chart = {
        'title' : ligneParDepartement['NomDepartment'],
        'data':{
            'values' :ligneParDepartement['PourcentageAbstention']
            },
        'mark': 'bar',
        "encoding": {
            "x": {"field": "Annee", "type": "ordinal"},
            "y": {"field": "PourcentageAbstention", "type": "quantitative",
                  "axis": {"title": "Abstention [%]"}}
            }
        }
    chart2 = {
        'title' : ligneParDepartement['NomDepartment'],
        'data':{
            'values' :ligneParDepartement['abstention']
            },
        'mark': 'bar',
        "encoding": {
            "x": {"field": "Annee", "type": "ordinal"},
            "y": {"field": "abstention", "type": "quantitative","axis": {"title": "Abstention"}}
            }
        }
    folium.Marker([ligneParDepartement['latitude'], ligneParDepartement['longitude']],
              popup=folium.Popup().add_child(folium.VegaLite(chart)), 
              icon=folium.Icon(color='purple', icon='info-sign')
              ).add_to(m)
    folium.Marker([ligneParDepartement['latitude'], ligneParDepartement['longitude']],
              popup=folium.Popup().add_child(folium.VegaLite(chart2)), 
              icon=folium.Icon(color='purple', icon='info-sign')
              ).add_to(m2)

m.save('pourcentageAbstention.html')
m2.save('abtention.html')







    